
/*(10 poena)
Napraviti klasu sportista koja od polja ima:
○ imePrezime (string - ime i prezime sportiste)
○ visina (decimalni broj koji predstavlja visinu sportiste u metrima)
○ timovi (niz stringova - timovi u kojima je sve ovaj sportista igrao)*/


// Napraviti niz od najmanje tri objekta (najmanje tri sportiste)
let sportista1={
	imePrezime:'PeraPeric',
	visina:1.98,
	timovi:['zvezda', 'spartak', 'barselona']


};


let sportista2={
	imePrezime:'ZikaZikic',
	visina:1.88,
	timovi:['zvezda','fenerbahce', 'unikaha']


};


let sportista3={
	imePrezime:'PeraPeric',
	visina:2.08,
	timovi:['fenerbahce', 'partizan']


};


let sportista4={
	imePrezime:'FilipFilipovic',
	visina:2.09,
	timovi:['fenerbahce', 'partizan', 'real']


};

let sportisti=[sportista1,sportista2,sportista3,sportista4];
console.log(sportisti);


/*(10 poena)
Napisati funkciju prosečnaVisina kojoj se prosleđuje niz sportista, a ona vraća
prosečnu visinu sportista. Pozvati funkciju i rezultat ispisati u konzoli.*/


let prosecnaVisina=niz=>{

	let sum=0;
	let br=0;
	niz.forEach(a=>{

		sum+=a.visina;
		br++;


	});

	let prosek=sum/br;
	return prosek;



}
console.log(prosecnaVisina(sportisti));







/*(20 poena)
Napisati funkciju igraliZaTim kojoj se prosleđuje niz sportista i naziv tima, a funkcija
prebrojava koliko puta se prosleđeni tim pojavljuje među timovima za koje su
sportisti igrali i vraća taj broj.*/




let igraliZaTim=(niz,naziv)=>{


	let br=0;
	niz.forEach(a=>{

		let ar=a.timovi;
		ar.forEach(b=>{
			if (b==naziv)
			 {

			 	br++;
			 }

		});


	});

return br;

}

console.log(igraliZaTim(sportisti,'zvezda'));




/*(20 poena)
Napisati funkciju najmanjeTransfera kojoj se prosleđuje niz sportista, a funkcija
vraća ime i prezime onog sportiste koji je imao najmanji broj transfera (najmanje
puta je promenio tim). Pozvati funkciju i rezultat ispisati u konzoli.*/




let najmanjeTransfera=niz=>{
		
		let ind=0;
		let min=niz[0].timovi.length;
		

		for (let i=0; i<niz.length; i++)
		{

			if (niz[i].timovi.length<min)

			 {
			 	min=niz[i].timovi.length;
			 	ind=i;

			 }
		}
		
return niz[ind].imePrezime;

		
 		
		

}

console.log(najmanjeTransfera(sportisti));







/*(20 poena)
Trener igrače na treningu deli u dve grupe kako bi se što bolje pripremili za
utakmicu. Kada trener dobije spisak sportista (niz sportista) on ih deli na sledeći
način:
○ U prvi tim smešta igrače sa parnim indeksom
○ U drugi tim smešta igrače sa neparnim indeksom
Napisati funkciju višiTim, kojoj se prosleđuje niz sportista a funkcija ispisuje na
ekranu tekst “Viša je prva grupa” ukoliko je prosečna visina igrača u prvoj grupi
veća od prosečne visine igrača u drugoj grupi. U suprotnom funkcija na ekranu
ispisuje “Viša je druga grupa”. Pozvati funkciju.*/




let visiTim=niz=>{
	let c=[];
	let d=[];
	let br=0;
	let br1=0;

	for(let i=0; i<niz.length; i++)
	{

		if (i%2==0) 

		{

			c.push(niz[i].visina);
			br++;
		}

		if (i%2!=0)
		 {

		 	d.push(niz[i].visina);
		 	br1++;
		 }

	}

console.log(c,d);
console.log(br,br1);
let sum1=0
let sum2=0;
for(let i=0; i<c.length; i++)
{


	sum1+=c[i];
	

}
let prosekpoz=sum1/br;
console.log(prosekpoz);


for(let i=0; i<d.length; i++)
{


	sum2+=d[i];

}

let prosekneg=sum2/br1;
console.log(prosekneg);




if (prosekpoz>prosekneg)

 {


 	console.log(`visa je prva grupa`);
 }

 else{


 	console.log(`visa je druga grupa`);
 }

}

visiTim(sportisti);





/*(20 poena)
Napisati funkciju trenerVidi kojoj se prosleđuje niz sportista a funkcija vraća
vrednost (ceo broj) koliko sportista trener vidi.
Pretpostavimo da sportisti stoje u vrsti, kao na sledećoj slici, a da trener stoji pre
prvog sportiste u vrsti(pre nultog elementa u nizu).
Vaš zadatak je da prebrojite koliko sportista trener može da vidi sa svoje pozicije.*/


let trenerVidi=niz=>{

let br=1;
let max=niz[0].visina;

for(let i=0; i<niz.length; i++)
{

	if (niz[i].visina>max)

	 {
	 	max=niz[i].visina;
	 	br++;
	 	//console.log(br);
	 }


}

return br;

}
console.log(trenerVidi(sportisti));







































