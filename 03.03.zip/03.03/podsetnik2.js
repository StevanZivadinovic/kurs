
//uvek na vrhu JavaScripta da budu preuzeti elementi a dole da se radi s njima


let ulZadaci=document.querySelector('ul');
let liZadaci=document.querySelectorAll('li');


//da ne bi za svaki list item postavljali eventListenery mi cemo 
//da prodjemo forEach petljom kroz list iteme;





	ulZadaci.addEventListener('dblclick',(e)=>{//dblcklick - neophodno je da se dva 
		//puta klilkne za akciju. 
		//ako se umesto ovi praznih zagrada stavi promenljiva
		// ne moramo izand da koristimo forEach petlju!!!!!!!

		//console.log(e.target);//ovo target je jedna od stavki koja se nalazi u okviru e elementa
		
		if(e.target.style.textDecoration=='line-through'){


		
		e.target.style.textDecoration='none';
		
		}
		else
		{
			e.target.style.textDecoration='line-through';
		}
	});





































