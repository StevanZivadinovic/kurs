




/*let dugme=document.querySelectorAll('li');

dugme.forEach(a=>{


a.addEventListener('click',()=>{

	if (a.style.textDecoration=="line-through") {

	a.style.textDecoration="none";
	}

	else
	{
	a.style.textDecoration="line-through";


	}
});

});*/

let ul=document.querySelector('ul');


//li.forEach(a=>{ //moze i sa forEach petljom da se radi,
// s tim sto u sledecem redu umesto ul pises a. Ali ako radis tako onda brise samo li iteme,
//nece da izbrise celu listu ako kliknes na medju prostor

	ul.addEventListener('click',(e)=>{//e posmatra celu ul listu i sve li u njemu i posmatra ih
		//kao zasebne celine. Tako da ako kliknes sad na medju prostor izmedju dva li-a on ce da
		//obrise celu listu. Ako kliknes samo na li item izbrisace samo jedan li item, bas taj na koji
		//si kliknuo. Znaci e hvata kliknuti element nezavisno dal se on nalazi u nekom vecem roditeljskom\
		//elementu. e se ne krece kroz nizove ili slicno vec samo hvata jedan element i onda mozes da radis
		//s tim elementom neke dalje stvari

		e.target.remove();

	});


//});
let input1=document.querySelector('#unos');
let li=document.querySelectorAll('li');
let dugme=document.querySelector('#Dodaj');


let nekaFunkcija=()=>{

let input=document.querySelector('#unos').value;
let noviLi=document.createElement('li');
let rbDodajNaPocetak=document.querySelector('#PocDod');
let rbDodajNaKraj=document.querySelector('#KrajDod');




	if (input=="")
	 {
	 	alert(`unesite text`);
	 }


	 else
	 {


	 		
	 		noviLi.textContent=input;
			ul.prepend(noviLi);

	 	if (rbDodajNaPocetak.checked) {
		ul.prepend(noviLi);
	 		
	 	}

	 	else
	 	{
	 		ul.append(noviLi);
	 		
	 		
	 	}
	 }
	 document.querySelector('input').value="";

};


dugme.addEventListener('click',()=>{

	nekaFunkcija();
});







input1.addEventListener('keyup',(e)=>{


if (e.keyCode==13)

 {
 	nekaFunkcija();
 }

});










