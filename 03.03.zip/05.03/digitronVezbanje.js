



let brojevi=document.querySelectorAll('.broj');
let operacije=document.querySelectorAll('.operacija');
let rez=document.querySelector('#jednako');
let paragraf=document.querySelector('#rezultat');
let x=0;
let y=0;
let op="";




brojevi.forEach(a=>{

a.addEventListener('click',()=>{



	if (x==0)

	 {

	 	x=a.textContent;
	 }

	 else
	 {

	 	y=a.textContent;
	 }

});

});




operacije.forEach(a=>{

a.addEventListener('click',()=>{

	op=a.textContent;
});
});


rez.addEventListener('click',()=>{
	x=parseInt(x);
	y=parseInt(y);

if (op=="+")

 {
		let p=x+y;
 	paragraf.innerText=p;



 }

 if (op=="-")

 {
 	let p=x-y;
 	paragraf.innerText=p;

 	
 }

 if (op=="*")

 {

 	let p=x*y;
 	paragraf.innerText=p;

 }

 if (op=="/")

 {

 	let p=x/y;
 	paragraf.innerText=p;

 }
 
x=0;
y=0;//vraca vrednost promenljivih na pocetnu vrednost
rez=0;

});

















