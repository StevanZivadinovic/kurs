
//Klikom na dugme, prikazati poruku u konzoli nakon 2
//sekunde, i nakon pola sekunde.
let btn1=document.querySelector('#btn1');
btn1.addEventListener('click',()=>{
setTimeout(()=>{

	console.log(`poruka1`);

},  2000);

setTimeout(()=>{

console.log(`poruka2`);

},500);


});


//Prekidamo rad tajmera

let btn2=document.querySelector('#btn2');
btn2.addEventListener('click',()=>{

	clearTimeout();

});




/*let tabela = document.querySelector('table');
let sadrzaj = "";
imena.forEach( ime => {
    let item = `<tr><td>${ime}</td></tr>`;
    sadrzaj += item;
});
tabela.innerHTML += sadrzaj;)*/ //ovo je da ti ne izlazi tbody u konzli kad ubacujes redove i kolkone u 
//tabelu. Ovo uopste nije iz ove lekcije, nego sam ga samo tu ubacio da mi se ne izgubi.






















