let paragraf=document.querySelectorAll('.test');
console.log(paragraf);
console.log(typeof paragraf);


let pargrafTest=document.querySelectorAll('p.test');
console.log(pargrafTest);


let paragrafSvi=document.querySelectorAll('p');
console.log(paragrafSvi);

console.log(typeof pargrafSvi);



paragrafSvi.forEach(a=>{

console.log(a);
});

let kolekcijaKlasa=document.getElementsByTagName('div');
console.log(kolekcijaKlasa[1]);




let paragrafInner=document.querySelector('p');
paragrafInner.innerText+=`neki tekst`;
paragrafInner.innerHTML+=`<br><span>neki lepi text</span>`;




//Selektovati sve paragrafe i u svakom od njih pridodati tekst „VAŽNO!!!“


for(let i=0; i<paragrafSvi.length; i++){

	paragrafSvi[i].innerText+=`VAZNO!!!`;
}



//Ispisati kvadrate brojeva od 1 do n, svaki u novom paragrafu

for(let i=0; i<paragrafSvi.length; i++)

{


	let a=i**2;
	paragrafSvi[i].innerText+=`${a}`;
}



paragrafSvi.forEach((a,index)=>{
let kv=index*index;
a.innerText+=`${kv}`;


});




/*Napraviti niz od najmanje tri imena.
Proći nizom i imena ispisati:

Svako u novom paragrafu

 */

let imena=['Jovana','Miljana','Milena'];


paragrafSvi.forEach((a,index)=>{

	a.innerText+=`${imena[index]}`;

});


//U listi kao stavke liste


let lista=document.createElement('ul');
document.body.appendChild(lista);


imena.forEach(a=>{

lista.innerHTML+=`<li>${a}</li>`;
});

//U jednoj koloni tabele


let tabela=document.createElement('table');
document.body.appendChild(tabela);


imena.forEach(a=>{

tabela.innerHTML+=`<tr><td>${a}</td></tr>`;
});


let decaBody=document.body.children;
console.log(decaBody);


let niz1=Array.from(decaBody);

niz1.forEach(a=>{

console.log(a);

});


//dohvatamo svu decu ul liste

let niz2=lista.children;
console.log(niz2);

let niz3=Array.from(niz2);


niz3.forEach(a=>{
console.log(a);

});





let ul=document.querySelector('ul');
let otacParagraf=ul.parentElement;
console.log(ul.parentElement.previousElementSibling);



let kreiranLink=document.createElement('a');
let link=document.body.appendChild(kreiranLink);
let dodavanje=link.setAttribute('href','http://facebook.com');
console.log(link.getAttribute('href'));
let kreiranLink1=document.createElement('a');
let link1=document.body.appendChild(kreiranLink);
let kreiranLink2=document.createElement('a');
let link2=document.body.appendChild(kreiranLink);


link.innerHTML+=`facebook<br>`;
link1.innerHTML+=`facebook<br>`;
link2.innerText+=`facebook`;




//1.Svim linkovima na stranici postaviti da se otvaraju u novom tabu.


let niz=['_blank','_blank','_blank'];
let linkovi=document.querySelectorAll('a');

linkovi.forEach((a,index)=>{

a.setAttribute('target','_blank');
});


//2.Svim slikama dodati alternativni tekst.

let slika1=document.createElement('img');
document.body.appendChild(slika1);

let slika2=document.createElement('img');
document.body.appendChild(slika2);


let slike=document.querySelectorAll('img');


slike.forEach(a=>{

a.setAttribute('alt','neka alternativna slika');
});



//3.Svim paragrafima postaviti atribut style tako da budu obojeni ljubičastom bojom.


paragrafSvi.forEach(a=>{

a.setAttribute('style','color:purple');
});


//Sve parne paragrafe na stranici obojiti zelenom bojom,
// a sve neparne paragrafe obojiti crvenom bojom.


paragrafSvi.forEach((a,index)=>{

if (index%2==0)

 {

 	a.style.color='green';
 }

 else
 {

 	a.style.color='red';
 }

});



/*Svim linkovima na stranici postaviti padding na
5px, font size na 18px i text-decoration na none.
Parnim linkovima staviti zelenu pozadinsku boju i
ljubicastu boju teksta, a neparnim linkovima plavu
pozadinsku boju i belu boju teksta.*/

let linkovi1=document.querySelectorAll('.link');
linkovi1.forEach((a,index)=>{

a.style.padding='5px';
a.style.fontSize='18px';
a.style.textDecoartion='none';


	if (index%2==0)

 	{

 	a.style.backgroundColor='green';
 	a.style.color='red';
 	}

 	else

 	{
 		a.style.backgroundColor='blue';
 		a.style.color='white';
 	}

});





//Tekst u paragrafima naizmenično pisati veličinom
//15px, veličinom 20px i veličinom od 25px.

paragrafSvi.forEach((a,index)=>{

	if (index%3==0) 

	{
		a.style.fontSize='15px';
	}

	else if (index%3==1)

	 {
	 	a.style.fontSize='20px';

	 }

	 else
	 {
	 	a.style.fontSize='25px';
	 }
});



/*Svim paragrafima čiji tekst sadrži reč error,
postaviti klasu na error, svim paragrafima čiji tekst
sadrži reč success, postaviti klasu na success. Ostale
kalse paragrafa ne modifikovati.*/


paragrafSvi.forEach(a=>{

	if (a.textContent.includes('error'))

 		{

 			a.classList.add('error');
 		}

	else if (a.textContent.includes('success'))
		{
			a.classList.add('success');

		}
}); //ovo mi nesto nije radilo, nzm sto, ima neki zajeb mali verovatno







//DODAVNJE I BRISANJE HTML TAGOVA





//dodati nov div tag dokumentu

let div=document.createElement('div');
document.body.appendChild(div);
console.log(div);



//Formirati ul listu sa stavkama čiji je sadržaj proizvoljan
//tekst, i dodati je div elementu.



let ulLista=document.createElement('ul');
document.body.appendChild(ulLista);

let niz11=['marija','darija','miljana'];
niz11.forEach((a,index)=>{
ulLista.innerHTML+=`<li>${niz11[index]}</li>`;

});



//Iz ul liste izbaciti prvu stavku.
//ulLista.removeChild(ulLista.children[1]);


//U ul listi zameniti drugu stavku liste.


let liPom=document.createElement('li');
liPom.innerText='***';
ulLista.replaceChild(liPom,ulLista.children[1]);






















