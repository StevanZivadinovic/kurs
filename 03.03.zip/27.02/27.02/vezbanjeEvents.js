let pozdravnoDugme=document.querySelector('button');

pozdravnoDugme.addEventListener('click',()=>{

alert('hello');

});


/*Napraviti dugme klikom na koje se u konzoli
ispisuje vrednost brojača br.
Brojač na početku ima vrednost 1, a svaki put
kada se klikne na dugme povećati vrednost
brojača za 1. */



let dugme=document.querySelector('#button');
let dugme1=document.querySelector('#button1');
let span=document.querySelector('span');
let br1=0;
dugme.addEventListener('click',()=>{

br1++;
span.innerText=`${br1}`;



});

dugme1.addEventListener('click',()=>{

br1--;
span.innerText=`${br1}`;



});




/*Napraviti input polje i dugme.
U input polje treba da se unese ime neke osobe, a
na ekranu u paragrafu da se ispiše Zdravo i ime
osobe preuzeto iz input polja. */


let ime=document.getElementById('ime');


ime.addEventListener('click',()=>{


let paragraf=document.querySelector('#par');	
let vrednost=document.querySelector('#pop').value;
paragraf.innerText=`Zdravo  ${vrednost}`;


});



//Napraviti sledeću formu i rezultat računanja ispisati
//u paragrafu ispod nje.

let dugme11=document.querySelector('#kv');
dugme11.addEventListener('click',()=>{

let kvadrat=document.querySelector('#kvadrat').value;
let paragraf1=document.querySelector('#par1');
let kv=kvadrat*kvadrat;

paragraf1.innerText=kv;

});

















