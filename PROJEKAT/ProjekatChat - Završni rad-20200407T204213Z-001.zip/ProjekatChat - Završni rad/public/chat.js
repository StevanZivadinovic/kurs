export class Chatroom{

    // Konstruktor
    constructor(r, u){
        this.room = r;
        this.username = u;
        this.chats = db.collection('chats');
        this.unsub;
    }

    // Seteri
    set username(u){
        this._username = u;
    }
    set room(r){
        this._room = r;
    }

    // Geteri
    get username(){
        return this._username;
    }
    get room(){
        return this._room;
    }

    async addChat(mess){

        //Dohvatanje tekućeg datuma koji je potreban za timestamp
        let date = new Date();

        // Kreiranje objekta/dokumenta koji prosleđujemo bazi podataka
        let docChat = {
            message: mess,
            username: this.username,
            room: this.room,
            created_at: firebase.firestore.Timestamp.fromDate(date)
        };

        //Da sačuvamo dokument u bazi
        let response = await this.chats.add(docChat); 
        return response;
    }

    async deleteChat(id){
        var r = confirm("Da li želite da trajno obrišete poruku?");
        if(r){
            db.collection('chats')
            .doc(id)
            .delete()
            .then(() => {
                console.log("Zadatak izbrisan");
            })
            .catch(error => {
                console.log(`Nemoguce obrisati dokument: ${error}`);
            });
            return true;
        } 
        return false;
    }

    getChets(callback){
        this.unsub = this.chats
            .where('room','==',this.room)
            .orderBy('created_at')
            .onSnapshot( snapshot => {
                snapshot.docChanges().forEach( change => {
                    //Ako je poruka dodata u bazu onda raditi update
                    if( change.type === 'added' ){
                        //uradi update
                        // console.log(change);
                        // console.log(change.doc.id);
                        callback(change.doc);
                    }
                });
            });
    }

    setTimeStamp(dateElement){
        let date = document.querySelector(dateElement);
        let dateValue = new Date(date.value);    
        let dateFirestore = firebase.firestore.Timestamp.fromDate(dateValue);
        return dateFirestore;
    }

    getChetsByDate(callback){
        let startDate = this.setTimeStamp('#dateStart');
        let dateEnd = this.setTimeStamp('#dateEnd');
        this.chats
            .where('room','==',this.room)
            .where('created_at','<=', dateEnd)
            .where('created_at', '>=', startDate)
            .orderBy('created_at')
            .onSnapshot( snapshot => {
                snapshot.docChanges().forEach( change => {
                    if( change.type === 'added' ){
                        callback(change.doc);
                    }
                });
            });
    }

    updateUsername(uu){
        //Suštinski menja samo vrednost lokalne promenljive, ne menja vrednost username u bazi podataka
        this.username = uu;
        localStorage.setItem('usernameLS', uu);
    }

    updateRoom(ur){
        this.room = ur;
        //console.log("Updated room");
        if(this.unsub){
            this.unsub();
        }
    }

}
